import tkinter as tk  # For the GUI
from tkinter import messagebox  # For alerts
from tkinter import ttk  # For Treeview table and styled widgets
import pandas as pd  # For handling Excel files
import os  # For file paths
import traceback  # For better error details
from datetime import datetime  # For handling dates

# Set the full file path for your Excel sheet (in your specified folder)
EXCEL_FILE = r'D:\Easy Expense@Joe\Joe@Expense.xlsx'  # Updated path to the expenses file

# Define expense and income categories (added 'Gold Investment')
EXPENSE_SHEETS = ['Room Rent', 'Current Bill', 'Water Bill', 'Food', 'Travel to Office', 'Travel to Home Town', 'Electronics', 'RND', 'Entertainment', 'Phone Recharge', 'Other Expense', 'Gold Investment']
INCOME_SHEETS = ['Monthly Income', 'Part-time Income']
ALLOWED_SHEETS = EXPENSE_SHEETS + INCOME_SHEETS

# Payment method options (updated with new methods)
PAYMENT_METHODS = ['GPay', 'Cash', 'Debit Card', 'TMB bank', 'IOB bank']

# Sheet options (categories)
SHEETS = ALLOWED_SHEETS  # Use the same list for combobox

def levenshtein(s, t):
    """Compute the Levenshtein distance between two strings."""
    m, n = len(s), len(t)
    if m == 0:
        return n
    if n == 0:
        return m
    matrix = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        matrix[i][0] = i
    for j in range(n + 1):
        matrix[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost = 0 if s[i - 1] == t[j - 1] else 1
            matrix[i][j] = min(
                matrix[i - 1][j] + 1,      # deletion
                matrix[i][j - 1] + 1,      # insertion
                matrix[i - 1][j - 1] + cost  # substitution
            )
    return matrix[m][n]

def load_sheet(sheet_name):
    """Load a specific sheet into a DataFrame. If it doesn't exist, create a new one silently."""
    columns = ['Date', 'Description', 'Amount', 'Payment Method']
    if os.path.exists(EXCEL_FILE):
        try:
            df = pd.read_excel(EXCEL_FILE, sheet_name=sheet_name, engine='openpyxl', dtype={'Description': str})  # Treat description as string
            # Trim spaces (but preserve case)
            df['Description'] = df['Description'].str.strip()
            # Add missing columns if needed
            for col in columns:
                if col not in df.columns:
                    df[col] = None
            print(f"Loaded sheet '{sheet_name}' with {len(df)} rows. Descriptions: {df['Description'].tolist()}")  # Debug print
            return df
        except (ValueError, Exception) as e:  # Handle sheet not found or other errors silently
            print(f"Silent load error for '{sheet_name}': {str(e)} - creating new empty sheet.")  # Debug in console only
            print("Load error details:", traceback.format_exc())  # Debug details
            return pd.DataFrame(columns=columns)
    else:
        print(f"Excel file not found - will create on save.")  # Debug
        return pd.DataFrame(columns=columns)

def save_sheet(df, sheet_name):
    """Save the DataFrame to a specific sheet with error handling."""
    try:
        # Trim description on save (preserve case)
        df['Description'] = df['Description'].str.strip()
        mode = 'a' if os.path.exists(EXCEL_FILE) else 'w'
        with pd.ExcelWriter(EXCEL_FILE, engine='openpyxl', mode=mode, if_sheet_exists='replace') as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        messagebox.showinfo("Success", f"Updated sheet '{sheet_name}' successfully! (Rows: {len(df)})")
        print(f"File saved successfully at: {os.path.abspath(EXCEL_FILE)} (sheet: {sheet_name}, rows: {len(df)})")  # Debug
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save sheet {sheet_name}: {str(e)}\nTry closing the file or check permissions.")
        print("Save error details:", traceback.format_exc())

def add_or_update_entry():
    description = description_entry.get().strip()  # Preserve case
    amount_str = amount_entry.get()
    payment_method = payment_entry.get()
    sheet_input = sheet_entry.get().strip()
    
    # Validate sheet name (category)
    sheet = next((s for s in ALLOWED_SHEETS if s.lower() == sheet_input.lower()), 'Other Expense')  # Default to Other Expense if invalid
    if sheet_input and sheet_input.lower() not in [s.lower() for s in ALLOWED_SHEETS]:
        messagebox.showwarning("Invalid Category", f"Invalid category '{sheet_input}' - using 'Other Expense' instead.")
    
    if not description or not amount_str:
        messagebox.showerror("Error", "Description and Amount are required!")
        return
    
    try:
        amount = float(amount_str)
        if amount <= 0:
            messagebox.showerror("Error", "Amount must be a positive number.")
            return
    except ValueError:
        messagebox.showerror("Error", "Amount must be a number.")
        return
    
    df = load_sheet(sheet)
    
    # Case-insensitive match for existing description
    matching_indices = df.index[df['Description'].str.lower() == description.lower()].tolist()
    if matching_indices:
        index = matching_indices[0]
        previous_payment = df.at[index, 'Payment Method'] if pd.notna(df.at[index, 'Payment Method']) else "Not specified"
        previous_amount = df.at[index, 'Amount']
        
        # Notification for update
        update_message = f"Updating existing entry.\nPrevious Amount: {previous_amount}\nPrevious Payment: {previous_payment}"
        if payment_method and payment_method != previous_payment:
            update_message += f"\nNew Payment Method: {payment_method}"
        messagebox.showinfo("Update Notification", update_message)
        
        df.at[index, 'Amount'] += amount
        if payment_method:
            df.at[index, 'Payment Method'] = payment_method
        df.at[index, 'Date'] = datetime.now().strftime("%Y-%m-%d")  # Update date to today
        save_sheet(df, sheet)
    else:
        if not payment_method:
            messagebox.showerror("Error", "Payment Method is required for new entries!")
            return
        new_row = {'Date': datetime.now().strftime("%Y-%m-%d"), 'Description': description, 'Amount': amount, 'Payment Method': payment_method}
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        save_sheet(df, sheet)
    
    description_entry.delete(0, tk.END)
    amount_entry.delete(0, tk.END)
    # Do not clear payment_entry and sheet_entry

def view_all_entries():
    """View all entries from all sheets in table format."""
    # Get all sheet names in the file
    with pd.ExcelFile(EXCEL_FILE) as xls:
        all_sheets = xls.sheet_names
    
    # Pop-up for view all
    view_window = tk.Toplevel(root)
    view_window.title("All Entries - Table View")
    view_window.geometry("700x500")
    view_window.configure(bg="#E8F5E9")  # Light green background
    
    tk.Label(view_window, text="All Entries in All Categories (Table Format):", font=("Arial", 16, "bold"), bg="#E8F5E9", fg="#2E7D32").pack(pady=10)
    
    # Create Treeview table
    columns = ("Category", "Date", "Description", "Amount (₹)", "Payment Method")
    tree = ttk.Treeview(view_window, columns=columns, show="headings", height=15)
    tree.heading("Category", text="Category")
    tree.heading("Date", text="Date")
    tree.heading("Description", text="Description")
    tree.heading("Amount (₹)", text="Amount (₹)")
    tree.heading("Payment Method", text="Payment Method")
    tree.column("Category", width=150)
    tree.column("Date", width=100)
    tree.column("Description", width=150)
    tree.column("Amount (₹)", width=100)
    tree.column("Payment Method", width=150)
    tree.pack(pady=5, fill=tk.BOTH, expand=True)
    
    # Scrollbar for table
    scrollbar = ttk.Scrollbar(view_window, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    
    # Load data into table
    for sheet_name in all_sheets:
        df = load_sheet(sheet_name)
        for _, row in df.iterrows():
            tree.insert("", "end", values=(sheet_name, row['Date'], row['Description'], f"₹{row['Amount']}", row['Payment Method'] or 'Not specified'))
    
    close_button = tk.Button(view_window, text="Close", command=view_window.destroy, font=("Arial", 12), bg="#66BB6A", fg="#FFFFFF")
    close_button.pack(pady=10)

def view_monthly_summary():
    """View monthly wise total income, total expense, and balance."""
    # Get all sheet names in the file
    with pd.ExcelFile(EXCEL_FILE) as xls:
        all_sheets = xls.sheet_names
    
    monthly_data = {}
    
    for sheet_name in all_sheets:
        df = load_sheet(sheet_name)
        for _, row in df.iterrows():
            if pd.notna(row['Date']) and pd.notna(row['Amount']):
                month = row['Date'][:7]  # YYYY-MM
                if month not in monthly_data:
                    monthly_data[month] = {'income': 0.0, 'expense': 0.0}
                if sheet_name in INCOME_SHEETS:
                    monthly_data[month]['income'] += row['Amount']
                elif sheet_name in EXPENSE_SHEETS:
                    monthly_data[month]['expense'] += row['Amount']
    
    # Pop-up for monthly summary
    summary_window = tk.Toplevel(root)
    summary_window.title("Monthly Summary")
    summary_window.geometry("600x400")
    summary_window.configure(bg="#E8F5E9")  # Light green background
    
    tk.Label(summary_window, text="Monthly Wise Total Income, Expense, and Balance:", font=("Arial", 16, "bold"), bg="#E8F5E9", fg="#2E7D32").pack(pady=10)
    
    # Create Treeview table
    columns = ("Month", "Total Income (₹)", "Total Expense (₹)", "Balance (₹)")
    tree = ttk.Treeview(summary_window, columns=columns, show="headings", height=15)
    tree.heading("Month", text="Month")
    tree.heading("Total Income (₹)", text="Total Income (₹)")
    tree.heading("Total Expense (₹)", text="Total Expense (₹)")
    tree.heading("Balance (₹)", text="Balance (₹)")
    tree.column("Month", width=100)
    tree.column("Total Income (₹)", width=150)
    tree.column("Total Expense (₹)", width=150)
    tree.column("Balance (₹)", width=150)
    tree.pack(pady=5, fill=tk.BOTH, expand=True)
    
    # Scrollbar for table
    scrollbar = ttk.Scrollbar(summary_window, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    
    # Load data into table
    for month in sorted(monthly_data.keys()):
        inc = monthly_data[month]['income']
        exp = monthly_data[month]['expense']
        bal = inc - exp
        tree.insert("", "end", values=(month, f"₹{inc:.2f}", f"₹{exp:.2f}", f"₹{bal:.2f}"))
    
    close_button = tk.Button(summary_window, text="Close", command=summary_window.destroy, font=("Arial", 12), bg="#66BB6A", fg="#FFFFFF")
    close_button.pack(pady=10)

def delete_entry():
    description = description_entry.get().strip()  # Preserve case for display, but search case-insensitive
    sheet_input = sheet_entry.get().strip()
    
    if not description or not sheet_input:
        messagebox.showerror("Error", "Description and Category are required!")
        return
    
    # Validate sheet name (category)
    sheet = next((s for s in ALLOWED_SHEETS if s.lower() == sheet_input.lower()), None)
    if not sheet:
        messagebox.showerror("Error", f"Invalid category '{sheet_input}'.")
        return
    
    df = load_sheet(sheet)
    
    # Case-insensitive match
    matching_indices = df.index[df['Description'].str.lower() == description.lower()].tolist()
    if matching_indices:
        index = matching_indices[0]
        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete:\nDescription: {df.at[index, 'Description']}\nAmount: ₹{df.at[index, 'Amount']}\nFrom category: {sheet}?")
        if confirm:
            df = df.drop(index)
            save_sheet(df, sheet)
            messagebox.showinfo("Success", "Entry deleted successfully!")
    else:
        messagebox.showerror("Error", "Entry not found!")
    
    description_entry.delete(0, tk.END)

def view_overall_summary():
    """View overall total income, total expense, and balance across all time."""
    # Get all sheet names in the file
    with pd.ExcelFile(EXCEL_FILE) as xls:
        all_sheets = xls.sheet_names
    
    total_income = 0.0
    total_expense = 0.0
    
    for sheet_name in all_sheets:
        df = load_sheet(sheet_name)
        for _, row in df.iterrows():
            if pd.notna(row['Amount']):
                if sheet_name in INCOME_SHEETS:
                    total_income += row['Amount']
                elif sheet_name in EXPENSE_SHEETS:
                    total_expense += row['Amount']
    
    total_balance = total_income - total_expense
    
    # Pop-up for overall summary
    summary_window = tk.Toplevel(root)
    summary_window.title("Overall Summary")
    summary_window.geometry("400x300")
    summary_window.configure(bg="#E8F5E9")  # Light green background
    
    tk.Label(summary_window, text="Overall Total Income, Expense, and Balance:", font=("Arial", 16, "bold"), bg="#E8F5E9", fg="#2E7D32").pack(pady=10)
    
    tk.Label(summary_window, text=f"Total Income: ₹{total_income:.2f}", font=("Arial", 14), bg="#E8F5E9", fg="#2E7D32").pack(pady=5)
    tk.Label(summary_window, text=f"Total Expense: ₹{total_expense:.2f}", font=("Arial", 14), bg="#E8F5E9", fg="#2E7D32").pack(pady=5)
    tk.Label(summary_window, text=f"Total Balance: ₹{total_balance:.2f}", font=("Arial", 14), bg="#E8F5E9", fg="#2E7D32").pack(pady=5)
    
    close_button = tk.Button(summary_window, text="Close", command=summary_window.destroy, font=("Arial", 12), bg="#66BB6A", fg="#FFFFFF")
    close_button.pack(pady=10)

def view_ai_tips():
    """View AI tips: top 5 expense categories per month."""
    # Get all sheet names in the file
    with pd.ExcelFile(EXCEL_FILE) as xls:
        all_sheets = xls.sheet_names
    
    monthly_expenses = {}
    
    for sheet_name in all_sheets:
        if sheet_name not in EXPENSE_SHEETS:
            continue
        df = load_sheet(sheet_name)
        for _, row in df.iterrows():
            if pd.notna(row['Date']) and pd.notna(row['Amount']):
                month = row['Date'][:7]  # YYYY-MM
                if month not in monthly_expenses:
                    monthly_expenses[month] = {}
                if sheet_name not in monthly_expenses[month]:
                    monthly_expenses[month][sheet_name] = 0.0
                monthly_expenses[month][sheet_name] += row['Amount']
    
    if not monthly_expenses:
        messagebox.showinfo("No Data", "No expense data available for tips.")
        return
    
    # Pop-up for AI tips
    tips_window = tk.Toplevel(root)
    tips_window.title("AI Expense Tips")
    tips_window.geometry("600x400")
    tips_window.configure(bg="#E8F5E9")  # Light green background
    
    tk.Label(tips_window, text="AI Tips: Top 5 Expense Categories Per Month", font=("Arial", 16, "bold"), bg="#E8F5E9", fg="#2E7D32").pack(pady=10)
    
    # Create Treeview table
    columns = ("Month", "Rank", "Category", "Amount (₹)", "Tip")
    tree = ttk.Treeview(tips_window, columns=columns, show="headings", height=15)
    tree.heading("Month", text="Month")
    tree.heading("Rank", text="Rank")
    tree.heading("Category", text="Category")
    tree.heading("Amount (₹)", text="Amount (₹)")
    tree.heading("Tip", text="Tip")
    tree.column("Month", width=100)
    tree.column("Rank", width=50)
    tree.column("Category", width=150)
    tree.column("Amount (₹)", width=100)
    tree.column("Tip", width=200)
    tree.pack(pady=5, fill=tk.BOTH, expand=True)
    
    # Scrollbar for table
    scrollbar = ttk.Scrollbar(tips_window, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    
    # Load data into table with top 5 per month and simple tip
    for month in sorted(monthly_expenses.keys()):
        expenses = monthly_expenses[month]
        sorted_expenses = sorted(expenses.items(), key=lambda x: x[1], reverse=True)[:5]  # Top 5
        for rank, (category, amount) in enumerate(sorted_expenses, start=1):
            tip = f"Rank {rank}: Consider reviewing spending on {category}."
            tree.insert("", "end", values=(month, rank, category, f"₹{amount:.2f}", tip))
    
    close_button = tk.Button(tips_window, text="Close", command=tips_window.destroy, font=("Arial", 12), bg="#66BB6A", fg="#FFFFFF")
    close_button.pack(pady=10)

# Create the GUI with beautiful centered layout and green color scheme
root = tk.Tk()
root.title("Easy Finance Tracker")  # Updated name to include finances
root.geometry("800x600")  # Larger window for professional feel
root.resizable(True, True)
root.configure(bg="#E8F5E9")  # Light mint green background

# Top header with title and tagline
header_frame = tk.Frame(root, bg="#2E7D32", height=80)  # Deep emerald green header bar
header_frame.pack(fill=tk.X)
tk.Label(header_frame, text="Easy Finance Tracker", font=("Arial", 24, "bold"), bg="#2E7D32", fg="#FFFFFF").pack(pady=10)
tk.Label(header_frame, text="Track Your Daily & Monthly Finances Effortlessly (Amounts in Rupees Only)", font=("Arial", 12, "italic"), bg="#2E7D32", fg="#E8F5E9").pack()

# Main content frame (centered)
main_frame = tk.Frame(root, bg="#E8F5E9")
main_frame.pack(expand=True, fill=tk.BOTH, pady=40)

# Centered input panel with shadow effect
input_frame = tk.Frame(main_frame, bg="#FFFFFF", bd=5, relief=tk.RIDGE, padx=20, pady=20)  # White panel with border and padding
input_frame.pack(pady=20)  # Center it

# Vertical stack of inputs with larger fonts and spacing
tk.Label(input_frame, text="Description:", font=("Arial", 14), bg="#FFFFFF").pack(anchor=tk.W, pady=5)
description_entry = tk.Entry(input_frame, font=("Arial", 14), width=40)
description_entry.pack(pady=5)

tk.Label(input_frame, text="Amount (in Rupees):", font=("Arial", 14), bg="#FFFFFF").pack(anchor=tk.W, pady=5)
amount_entry = tk.Entry(input_frame, font=("Arial", 14), width=40)
amount_entry.pack(pady=5)

tk.Label(input_frame, text="Payment Method:", font=("Arial", 14), bg="#FFFFFF").pack(anchor=tk.W, pady=5)
payment_entry = ttk.Combobox(input_frame, values=PAYMENT_METHODS, font=("Arial", 14), width=38)
payment_entry.pack(pady=5)

tk.Label(input_frame, text="Category:", font=("Arial", 14), bg="#FFFFFF").pack(anchor=tk.W, pady=5)
sheet_entry = ttk.Combobox(input_frame, values=SHEETS, font=("Arial", 14), width=38)
sheet_entry.pack(pady=5)

# Bottom toolbar for actions (horizontal buttons)
toolbar_frame = tk.Frame(main_frame, bg="#66BB6A", pady=10)  # Mid-green toolbar
toolbar_frame.pack(fill=tk.X, pady=20)

add_update_button = tk.Button(toolbar_frame, text="Add/Update Entry", command=add_or_update_entry, font=("Arial", 12), width=20, bg="#4CAF50", fg="white")
add_update_button.pack(side=tk.LEFT, padx=10)

view_button = tk.Button(toolbar_frame, text="View All Entries", command=view_all_entries, font=("Arial", 12), width=20, bg="#FF9800", fg="white")
view_button.pack(side=tk.LEFT, padx=10)

summary_button = tk.Button(toolbar_frame, text="Monthly Summary", command=view_monthly_summary, font=("Arial", 12), width=20, bg="#9C27B0", fg="white")
summary_button.pack(side=tk.LEFT, padx=10)

delete_button = tk.Button(toolbar_frame, text="Delete Entry", command=delete_entry, font=("Arial", 12), width=20, bg="#F44336", fg="white")
delete_button.pack(side=tk.LEFT, padx=10)

overall_summary_button = tk.Button(toolbar_frame, text="Overall Summary", command=view_overall_summary, font=("Arial", 12), width=20, bg="#2196F3", fg="white")
overall_summary_button.pack(side=tk.LEFT, padx=10)

ai_tips_button = tk.Button(toolbar_frame, text="AI Tips", command=view_ai_tips, font=("Arial", 12), width=20, bg="#FFC107", fg="black")
ai_tips_button.pack(side=tk.LEFT, padx=10)

# Bottom footer with name
footer_frame = tk.Frame(root, bg="#2E7D32", height=30)  # Deep emerald green footer bar
footer_frame.pack(fill=tk.X, side=tk.BOTTOM)
tk.Label(footer_frame, text="Easy Finance Tracker - Easy Entry", font=("Arial", 10), bg="#2E7D32", fg="#FFFFFF").pack(side=tk.RIGHT, padx=10)

# Key bindings
entries = [description_entry, amount_entry, payment_entry, sheet_entry]

def move_focus_up(event):
    current = root.focus_get()
    if current in entries:
        idx = entries.index(current)
        new_idx = (idx - 1) % len(entries)
        entries[new_idx].focus()

def move_focus_down(event):
    current = root.focus_get()
    if current in entries:
        idx = entries.index(current)
        new_idx = (idx + 1) % len(entries)
        entries[new_idx].focus()

root.bind('<Return>', lambda event: add_or_update_entry())
root.bind('<Up>', move_focus_up)
root.bind('<Down>', move_focus_down)

root.mainloop()